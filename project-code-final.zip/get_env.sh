cat .env
